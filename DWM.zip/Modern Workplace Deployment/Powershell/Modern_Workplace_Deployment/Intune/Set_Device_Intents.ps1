param (
    [parameter(Mandatory=$true)][string]$Token,
    [Parameter(Mandatory=$false)][bool]$Update
)

. (Join-Path $PSScriptRoot "..\..\Functions\Function_Invoke-RestMethod.ps1")

function Invoke-IntuneRestoreConfigurationPolicy {

param (
    [Parameter(Mandatory=$false)][bool]$Update
    )

$policy_Type = "Device_Intents"
$JSON_Location = Join-Path $PSScriptRoot "baselinefiles\$($policy_Type)"

$policies = Get-ChildItem -Path $JSON_Location -File

foreach ($policy in $policies) 
            {          
            $Policy_Name =  ($policy.BaseName.Split("_")[1])
            write-host $Policy_Name
            $uri = "https://graph.microsoft.com/beta/deviceManagement/Intents?`$filter=(displayName eq '$($Policy_Name)')"
            $Existing_Policy = Call_RestMethod -Method get -Uri $uri -token $token

                if (!$Existing_Policy.value)
                    {
                        $JSON = Get-Content -Path (Join-Path $JSON_Location "$($policy.BaseName).json") -Raw
                        $DisplayName = $policy.BaseName
                        $templateId = $DisplayName.Split("_")[0]

                        #Create JSON Body
                        $Content = Get-Content -LiteralPath $policy.FullName
                        $JSON_Convert = $Content | ConvertFrom-Json | Select-Object -Property * -ExcludeProperty id, createdDateTime, lastModifiedDateTime, settingCount, creationSource 
                        $JSON_Output = $JSON_Convert | ConvertTo-Json -Depth 5

                        write-host "Create Device Configuration $($DisplayName)"
                        $uri = "https://graph.microsoft.com/beta/deviceManagement/templates/$($templateId)/createInstance"
                        $PolicyObject = Call_RestMethod -Method Post -body $JSON_Output -Uri $uri -token $token

                        if($PolicyObject)
                            {
                            $policyid = $PolicyObject.id
                       
                            $uri = "https://graph.microsoft.com/beta/deviceManagement/Intents/$($policyid)/assign"
                            
                            if ($DisplayName -like "* - C - *")
                                {
                                    $JSON = "{'assignments':[{'id':'','target':{'@odata.type':'#microsoft.graph.allDevicesAssignmentTarget','deviceAndAppManagementAssignmentFilterId':null,'deviceAndAppManagementAssignmentFilterType':'none'}}]}"
                                    Call_RestMethod -Method Post -body $JSON -Uri $uri -token $token
                                }
                            elseif ($DisplayName -like "* - U - *")
                                {
                                    $JSON = "{'assignments':[{'id':'','target':{'@odata.type':'#microsoft.graph.allLicensedUsersAssignmentTarget','deviceAndAppManagementAssignmentFilterId':null,'deviceAndAppManagementAssignmentFilterType':'none'}}]}"
                                    Call_RestMethod -Method Post -body $JSON -Uri $uri -token $token
                                }   
                            else     
                                {
                                write-host Naming convention not correct - skipping assignment -ForegroundColor Yellow
                                }
                        }
                    }
                    elseif ($update -eq $true)
                    {
                        $Policyid = $Existing_Policy.value.id
                        $uri = "https://graph.microsoft.com/beta/deviceManagement/Intents/$($Policyid)"

                        $JSON = Get-Content -Path (Join-Path $JSON_Location "$($policy.BaseName).json") -Raw
                        $DisplayName = $policy.BaseName
                        $templateId = $DisplayName.Split("_")[0]

                        #Create JSON Body
                        $Content = Get-Content -LiteralPath $policy.FullName
                        $JSON_Convert = $Content | ConvertFrom-Json | Select-Object -Property * -ExcludeProperty id, createdDateTime, lastModifiedDateTime, settingCount, creationSource 
                        $JSON_Output = $JSON_Convert | ConvertTo-Json -Depth 5

                        write-host "Updating Device Configuration Policy $($DisplayName)"
                        $PolicyObject = Call_RestMethod -Method Patch -body $JSON_Output -Uri $uri -token $token
                    }
                    else
                    {
                        write-host "$($Policy_Name) already exists, no update selected - skipping" -ForegroundColor Yellow
                    }
            }

        }
invoke-IntuneRestoreConfigurationPolicy $Update