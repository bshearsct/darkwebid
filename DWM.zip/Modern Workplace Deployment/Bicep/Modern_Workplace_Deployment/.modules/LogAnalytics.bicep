param location string
param logAnalyticsGeneralName string

//Log Analytics Variables
param publicaccess string = 'Enabled'
var LA_Name = logAnalyticsGeneralName

resource LogAnalytics 'Microsoft.OperationalInsights/workspaces@2021-06-01' = {
  name: LA_Name
  location:location
  properties: {
    sku: {
      name: 'PerGB2018'
    }
    retentionInDays: 365
    features: {
      searchVersion: 1
    }
    publicNetworkAccessForIngestion: publicaccess
    publicNetworkAccessForQuery: publicaccess
  }
}

output LA_Workspace string = LogAnalytics.id
