function Call_RestMethod {
    param (
        [parameter(Mandatory=$true)][string]$Token,
        [parameter(Mandatory=$true)][string]$Method,
        [parameter(Mandatory=$true)][string]$uri,
        [parameter(Mandatory=$false)][string]$body
    )

do
    {
        try {
            $headers = @{Authorization = "Bearer $($Token)" }

            if ($Method -eq "GET")
                    {
                       Invoke-RestMethod -Method $Method -Uri $uri -ContentType 'application/json' -Headers $headers
                    }
                    else
                    {
                        Invoke-RestMethod -Method $Method -Uri $uri -Body $body -ContentType 'application/json' -Headers $headers
                    }
            $statusCode = 200
        } catch {
            $statusCode = $_.Exception.Response.StatusCode.value__
            write-host $_.Exception.Message
        }

        if ($statusCode -eq 429)
        {
            Start-Sleep -Seconds 10
        }
    } while ($statusCode -eq 429)
}