function Set_Authentication_Strength {

$policy_Type = "Authentication_Strength"
$JSON_Location = Join-Path $PSScriptRoot "..\Intune\baselinefiles\$($policy_Type)"
$policies = Get-ChildItem -Path $JSON_Location -File

foreach ($Policy in $policies)          
            {
                $JSON = Get-Content -Path (Join-Path $JSON_Location $Policy) -Raw
                $PolicyName = $JSON | ConvertFrom-Json | Select-Object -Property Displayname -ExpandProperty Displayname

                $uri = "https://graph.microsoft.com/beta/identity/conditionalAccess/authenticationStrength/policies?$" + "filter=(Displayname eq '" + "$($policyname)" + "')"
                $Policy = Call_RestMethod -Method get -Uri $uri -token $token
                if ($policy.value)
                {
                    write-host "Authentication Strength $PolicyName Exists, skipping"
                }
                else
                {
                $uri = "https://graph.microsoft.com/beta/identity/conditionalAccess/authenticationStrength/policies"
                $Policy = Call_RestMethod -Method post -body $JSON -Uri $uri -token $token
                }
            }

        }