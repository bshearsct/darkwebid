param (
    [parameter(Mandatory=$true)][string]$token,
    [Parameter(Mandatory=$true)][string]$MAM_Groupname,
    [Parameter(Mandatory=$true)][string]$MAM_GroupDescription,
    [Parameter(Mandatory=$false)][bool]$Update,
    [Parameter(Mandatory=$false)][bool]$MAM_Block_MDM
)

. (Join-Path $PSScriptRoot "..\..\Functions\Function_Invoke-RestMethod.ps1")
. (Join-Path $PSScriptRoot "..\Functions\Function_Set_EntraID_Group.ps1")
. (Join-Path $PSScriptRoot "..\Functions\Function_Set_MAM_Enrollment_Profiles.ps1")

Set_EntraID_Group $MAM_Groupname $MAM_GroupDescription


if ($MAM_Block_MDM -eq $true)
    {
        Set_MAM_Enrollment
    }


function Set_Mobile_Application_Management {
    param (
        [Parameter(Mandatory=$true)][string]$GroupID,
        [Parameter(Mandatory=$false)][bool]$Update
    )

$policy_Type = "Mobile_Application_Management"
$JSON_Location = ".\Powershell\Modern_Workplace_Deployment\Intune\baselinefiles\$($policy_Type)"
$policies = Get-ChildItem -Path $JSON_Location -File

foreach ($policy in $policies) 
            {
            $JSON = Get-Content -Path "$($JSON_Location)\$($policy.BaseName).json" -Raw
            $PolicyName = $JSON | ConvertFrom-Json | Select-Object -Property Displayname -ExpandProperty Displayname
            $uri = "https://graph.microsoft.com/beta/deviceAppManagement/managedAppPolicies?`$filter=(displayName eq '$($PolicyName)')"
            $Existing_Policy = Call_RestMethod -Method get -Uri $uri -token $token

            if (!$Existing_Policy.value)
                {
                    $JSON_Convert = $JSON | ConvertFrom-Json | Select-Object -Property * -ExcludeProperty id,createdDateTime,lastModifiedDateTime,deviceConfigurationId,macOSCustomConfigurationReferenceUrl
                    $JSON_Output = $JSON_Convert | ConvertTo-Json -Depth 100
                    $uri = "https://graph.microsoft.com/beta/deviceAppManagement/managedAppPolicies"
                    $PolicyObject = Call_RestMethod -Method Post -body $JSON_Output -Uri $uri -token $token

                    if($PolicyObject)
                        {
                        $policyid = $PolicyObject.id                   
                        $JSON = @{
                            assignments = @(
                                @{
                                    target = @{
                                        groupId = "$($GroupID)"
                                        "@odata.type" = "#microsoft.graph.groupAssignmentTarget"
                                    }
                                }
                            )
                        }
                        $JSON_Convert = $JSON | ConvertTo-Json -Depth 3 

                        if ($PolicyName -like "*Android*")
                            {
                            $uri = "https://graph.microsoft.com/beta/deviceAppManagement/androidManagedAppProtections/$($policyid)/assign"
                            }
                        elseif ($PolicyName -like "*iOS*")
                            {
                            $uri = "https://graph.microsoft.com/beta/deviceAppManagement/iosManagedAppProtections/$($policyid)/assign"
                            }      
                        Call_RestMethod -Method Post -body $JSON_Convert -Uri $uri -token $token
                        }
                        
                }
            elseif ($update -eq $true)
                {
                    $Policyid = $Existing_Policy.value.id                  
                    $JSON_Convert = $JSON | ConvertFrom-Json | Select-Object -Property * -ExcludeProperty id,createdDateTime,lastModifiedDateTime,deviceConfigurationId,macOSCustomConfigurationReferenceUrl
                    $JSON_Output = $JSON_Convert | ConvertTo-Json -Depth 100

                    $uri = "https://graph.microsoft.com/beta/deviceAppManagement/managedAppPolicies/$($Policyid)"
                    $PolicyObject = Call_RestMethod -Method Patch -body $JSON_Output -Uri $uri -token $token
                }
            else
                {
                    write-host "$($PolicyName) already exists, no update selected - skipping" -ForegroundColor Yellow
                }
        }    
    }

Set_Mobile_Application_Management $script:group.id $Update