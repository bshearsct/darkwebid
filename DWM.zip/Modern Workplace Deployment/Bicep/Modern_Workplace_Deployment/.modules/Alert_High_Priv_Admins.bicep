param location string
param LA_Workspace string
param alertname string = 'New Global Administrator or Privileged Role Administrator Added'
param query string =  'AuditLogs\n| where Category == "RoleManagement" \n| where OperationName  contains "Add" \n| where TargetResources contains "Global Administrator" or TargetResources contains "Privileged Role Administrator"'
param actiongroupname string = 'AG_SU_Support'

resource actiongroup 'Microsoft.Insights/actionGroups@2019-06-01' existing = {
  name: actiongroupname
}

resource alert 'microsoft.insights/scheduledqueryrules@2023-03-15-preview' = {
  name: alertname
  location: location
  properties: {
    actions: {
      actionGroups: [
        actiongroup.id
      ]
      customProperties: {}
    }
    displayName: alertname
    severity: 3
    enabled: true
    evaluationFrequency: 'PT5M'
    scopes: [
      LA_Workspace
    ]
    targetResourceTypes: [
      'microsoft.operationalinsights/workspaces'
    ]
    windowSize: 'PT5M'
    criteria: {
      allOf: [
        {
          query: query
          timeAggregation: 'Count'
          dimensions: []
          operator: 'GreaterThan'
          threshold: 0
          failingPeriods: {
            numberOfEvaluationPeriods: 1
            minFailingPeriodsToAlert: 1
          }
        }
      ]
    }
    autoMitigate: false
  }
}
