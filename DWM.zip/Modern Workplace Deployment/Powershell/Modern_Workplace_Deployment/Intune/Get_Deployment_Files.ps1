param (
    [Parameter(Mandatory=$true)][string]$Accesskey,
    [Parameter(Mandatory=$false)][string]$customername,
    [Parameter(Mandatory=$false)][string]$environment
    )

function get-deploymentfiles {
    param (
        [Parameter(Mandatory=$true)][string]$Accesskey,
        [Parameter(Mandatory=$false)][string]$customername,
        [Parameter(Mandatory=$false)][string]$environment
        )

        Write-Host "Getting data from the $environment environment"

        $Context = New-AzStorageContext -ConnectionString $Accesskey
        $JSON_Location = ".\Powershell\Modern_Workplace_Deployment\Intune\"
        $Content = Get-AzStorageFile -Context $context -sharename baselinefiles -path $environment | Get-AZStorageFile
            foreach ($item in $Content) {
                if ($item.GetType().Name -eq "AzureStorageFileDirectory")
                {   
                    New-Item ".\Powershell\Modern_Workplace_Deployment\Intune\baselinefiles\$($item.Name)" -ItemType Directory -Force
                    $files = Get-AzStorageFile -Context $context -sharename baselinefiles -path ($environment + "\" + $item.Name) | Get-AzStorageFile
                    foreach ($file in $files) {
                        $file | Get-AzStorageFileContent -Destination $JSON_Location\baselinefiles\$($item.Name) -Force | Out-Null
                        }
                }
            }
    
        $customershares = Get-AzStorageFile -Context $context -sharename customerdata   
        if ($customershares.name -contains $customername)
            {
            $Customerdata = ".\customers\$($customername)"
            $Customer_Content = Get-AzStorageFile -Context $context -sharename customerdata -path $customername | Get-AZStorageFile
        
            if ($Customer_Content)
                {
                foreach ($item in $Customer_Content) {
                    if ($item.GetType().Name -eq "AzureStorageFileDirectory")
                        {   
                            New-Item $Customerdata\$($item.Name) -ItemType Directory -Force
                            $files = Get-AzStorageFile -Context $context -sharename customerdata -path $customername\$($item.Name) | Get-AzStorageFile
                            foreach ($file in $files) {
                                $file | Get-AzStorageFileContent -Destination $Customerdata\$($item.Name) -Force | Out-Null
                                }
                        }
                    }
                }
            }
    }

Get-deploymentfiles -Accesskey $Accesskey -customername $customername -environment $environment