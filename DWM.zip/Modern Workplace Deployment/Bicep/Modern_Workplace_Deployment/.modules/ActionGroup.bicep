param notificationaddress string = 'support@score-utica.nl'

resource AlertGroup 'Microsoft.Insights/actionGroups@2019-06-01' = {
  location: 'global'
  name: 'AG_SU_Support'
  properties: {
    groupShortName: 'SU_Support'
    enabled: true
    emailReceivers: [
      {
        emailAddress: notificationaddress
        name: 'SU Topdesk'
        useCommonAlertSchema: true
      }
    ]
  }
}
