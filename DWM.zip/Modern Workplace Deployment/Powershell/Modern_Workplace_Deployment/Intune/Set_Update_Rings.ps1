param (
    [parameter(Mandatory=$true)][string]$Token,
    [parameter(Mandatory=$true)][string]$Update
)

. (Join-Path $PSScriptRoot "..\..\Functions\Function_Invoke-RestMethod.ps1")
. (Join-Path $PSScriptRoot "..\Functions\Function_Set_EntraID_Group.ps1")

function Set_Update_Rings {

$policy_Type = "Update_Rings"
$JSON_Location = ".\Powershell\Modern_Workplace_Deployment\Intune\baselinefiles\$($policy_Type)"

$policies = Get-ChildItem -Path $JSON_Location -File


function assign_policy {

    param (
        [parameter(Mandatory=$true)][string]$policyid,
        [parameter(Mandatory=$true)][string]$PolicyName
    )
        #Assign the policy
        if($PolicyName -like "*Acceptance*")
        {
            # Assign to the acceptance group
            Set_EntraID_Group -GroupName "SEC-C-Windows Update-Acceptance" -Group_Description "Acceptance Group for Windows Update"
            $uri = "https://graph.microsoft.com/beta/deviceManagement/deviceConfigurations/$($policyid)/assignments"

            $JSON = @{
                    target = @{
                                "@odata.type" = "#microsoft.graph.groupAssignmentTarget"
                                groupId = "$($script:group.id)"              
                                }
                    source = "direct"
                    } | ConvertTo-Json -Depth 3
            Call_RestMethod -Method Post -body $JSON -Uri $uri -token $Token
        }
    elseif ($PolicyName -like "*Production*")
        {
            Set_EntraID_Group -GroupName "SEC-C-Windows Update-Acceptance" -Group_Description "Acceptance Group for Windows Update"

            #Assign the policy to all device
            $uri = "https://graph.microsoft.com/beta/deviceManagement/deviceConfigurations/$($policyid)/assign"

            $JSON = "{'assignments':[{'id':'','target':{'@odata.type':'#microsoft.graph.allDevicesAssignmentTarget','deviceAndAppManagementAssignmentFilterId':null,'deviceAndAppManagementAssignmentFilterType':'none'}}]}"
            Call_RestMethod -Method Post -body $JSON -Uri $uri -token $Token
            
            # Exclude the acceptance group
            $uri = "https://graph.microsoft.com/beta/deviceManagement/deviceConfigurations/$($policyid)/assignments"
            $JSON = @{
                target = @{
                            "@odata.type" = "#microsoft.graph.exclusionGroupAssignmentTarget"
                            groupId = "$($script:group.id)"              
                            }
                source = "direct"
                } | ConvertTo-Json -Depth 3
            Call_RestMethod -Method Post -body $JSON -Uri $uri -token $Token
        }
}

foreach ($policy in $policies) 
            {       
            $JSON = Get-Content -Path "$($JSON_Location)\$($Policy.Name)" -Raw
            
            #Get Policy Displayname
            $PolicyName = $JSON | ConvertFrom-Json | Select-Object -Property Displayname -ExpandProperty Displayname

            #Create JSON Body
            $JSON_Convert = $JSON | ConvertFrom-Json | Select-Object -Property * -ExcludeProperty id,createdDateTime,lastModifiedDateTime                  
            $JSON_Output = $JSON_Convert | ConvertTo-Json -Depth 10

            $uri = "https://graph.microsoft.com/beta/deviceManagement/deviceConfigurations?`$filter=(displayName eq '$($PolicyName)')"
            $Existing_Policy = Call_RestMethod -Method get -Uri $uri -token $Token

                if (!$Existing_Policy.value)
                    {
                        write-host "Create $($PolicyName)"
                        $uri = "https://graph.microsoft.com/beta/deviceManagement/deviceConfigurations/"
                        $PolicyObject = Call_RestMethod -Method Post -body $JSON_Output -Uri $uri -token $Token

                        assign_policy -policyid $PolicyObject.id -PolicyName $PolicyName 
                    }
                elseif ($update -eq $true)
                    {
                        $Policyid = $Existing_Policy.value.id
                        $uri = "https://graph.microsoft.com/beta/deviceManagement/deviceConfigurations/$($Policyid)"

                        write-host "Update $($PolicyName)"
                        $PolicyObject = Call_RestMethod -Method Patch -body $JSON_Output -Uri $uri -token $Token
                        assign_policy -policyid $Policyid -PolicyName $PolicyName
                    }
                else
                    {
                        write-host "$($PolicyName) already exists, no update selected - skipping" -ForegroundColor Yellow
                    }
            }
        }

Set_Update_Rings -Token $Token -Update $Update