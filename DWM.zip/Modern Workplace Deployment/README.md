# Releasenotes

## Release 2026_Q3_001

### Code Change:
- Migrated to the new DevOps tenant
- Azure Deployment can be done in either West Europe, North Europe or Sweden Central



## Release 2026_Q2_001

### Code Change:
- Added a job in Intune Configuration: Configure_Default_Applications
    - Parameter default set to true, is changable when running the pipeline
    - Will install Microsoft Apps for 365 (with a multi-user device exclusion) and the Company portal app on all devices

### Bug fixes
- Added "AppRoleAssignment.ReadWrite.All" to the <i>Score Utica Automation</i> App Registration to consent the reporting SP.


## Release 2026_Q1_001

### Code Change:
- Added a new stage: Configure_SU_reporting
    - Add the Service Principal for reporting to the tenant
    - Add or update the customer in the reporting tenant
- Extended the scope for Score Utica Automation in Create_App_Registration.ps1: Be able to register and consent the SP for reporting

## Release 2025_Q2_001

### Bug fixes
- None

### Code Change:
- Get one session token instead of authenticating each time
- Use a function to call Rest Methods for error handling

## Release 2025_Q1

### Bug fixes
- MAM Conditional Policy was not created.

### Code Change:
- Recreated the App Registration so it also contains the correct Custom Azure Roles
- Automatically connect the Entra ID Diagnostics Settings to the Azure Log Analytics
    - Create an Azure Alert for Break-Glass logins
    - MAKE SURE THAT Access management for Azure resources in Entra id ENABLED
- Windows Updates now contain a Dev and Prod policy
    - Windows 11 upgrade is allowed

### Policy Settings - Entra ID
- Add new Authentication method rule: Third-party software OATH tokens - Enable for all users

### Policy Settings - Intune
- Changed Bitlocker policy:
    - Removed Removable storage from the main policy
    - Created a new policy for removable storage for All Users


## Release 2024_Q4

### Bug fixes
- When only configuring MAM, a Windows Update Ring is still configured
- When the prerequisites script runs to create the App Registration, the secret was instantly expired. Changed it to 7 days.

### Code Change:
- Reading values from the keyvault is now a task, removing the need of the Pipeline Library
- Split Mobile Device Management & Mobile Application Management in seperate jobs
- Updated the App Permissions in the Prereq file with the correct permissions
- More logical order in the Configure Tenant parameter set

### Policy Settings - Entra ID
- Add new CA rule: Allow - MFA - Admin roles to Admin Portals

### Policy Settings - Intune
- Changed UAC level: allowing prompts
- Changed Mobile Application Management: Allowing Biometrics and forcing a strong pin
- Changed MacOS deployment:
    - Block incoming firewall to not configured
    - Add Airdrop to Allowed list