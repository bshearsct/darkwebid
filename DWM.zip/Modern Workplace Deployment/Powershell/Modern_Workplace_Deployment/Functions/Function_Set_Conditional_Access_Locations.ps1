function Set_Conditional_Access_Locations {

$policy_Type = "Conditional_Access_Locations"
$JSON_Location = Join-Path $PSScriptRoot "..\Intune\baselinefiles\$($policy_Type)"
$policies = Get-ChildItem -Path $JSON_Location -File

foreach ($Policy in $policies)          
            {
                $JSON = Get-Content -Path (Join-Path $JSON_Location $Policy) -Raw
                $PolicyName = $JSON | ConvertFrom-Json | Select-Object -Property Displayname -ExpandProperty Displayname

                $uri = "https://graph.microsoft.com/beta/identity/conditionalAccess/namedLocations?`$filter=(Displayname eq '$($policyname)')"
                $location = Call_RestMethod -Method get -Uri $uri -token $token
                if ($location.value)
                {
                    if ($PolicyName -eq "Score Utica")
                        {
                            $PolicyID = $location.value.id
                            $uri = "https://graph.microsoft.com/beta/identity/conditionalAccess/namedLocations/$($PolicyID)"
                            $Policy = Call_RestMethod -Method Patch -body $JSON -Uri $uri -token $token
                        }
                }
                else
                {
                    $uri = "https://graph.microsoft.com/beta/identity/conditionalAccess/namedLocations"
                    $Policy = Call_RestMethod -Method post -body $JSON -Uri $uri -token $token
                }
            }
        }