param (
    [parameter(Mandatory=$true)][string]$token,
    [Parameter(Mandatory=$false)][bool]$Windows,
    [Parameter(Mandatory=$false)][bool]$macOS,
    [Parameter(Mandatory=$false)][bool]$Update,
    [Parameter(Mandatory=$true)][string]$customername
)

. (Join-Path $PSScriptRoot "..\..\Functions\Function_Invoke-RestMethod.ps1")

function Invoke-IntuneRestoreConfigurationPolicy {

param (
    [Parameter(Mandatory=$false)][bool]$Windows,
    [Parameter(Mandatory=$false)][bool]$macOS,
    [Parameter(Mandatory=$false)][bool]$Update,
    [Parameter(Mandatory=$true)][string]$customername
    )

$policy_Type = "Device_Configurations"
$JSON_Location = Join-Path $PSScriptRoot "baselinefiles\$($policy_Type)"

if (($Windows -eq $true) -and ($macOS -eq $true))
    {$policies = Get-ChildItem -Path $JSON_Location -File}
elseif (($Windows -eq $true) -and ($macOS -eq $false))
    {$policies = Get-ChildItem -Path $JSON_Location -File | Where-Object name -Like "Windows*"}
elseif (($Windows -eq $false) -and ($macOS -eq $true))
    {$policies = Get-ChildItem -Path $JSON_Location -File | Where-Object name -Like "mac*"}
else
    {Write-Warning "No operating system selected"}

foreach ($policy in $policies) 
            {          
            $Policy_Name =  ($policy.BaseName -replace '_','/')
            $uri = "https://graph.microsoft.com/beta/deviceManagement/deviceConfigurations?`$filter=(displayName eq '$($Policy_Name)')"
            $Existing_Policy  = Call_RestMethod -Method get -body $JSON -Uri $uri -token $token

                if (!$Existing_Policy.value)
                    {
                        $JSON = Get-Content -Path (Join-Path $JSON_Location "$($policy.BaseName).json") -Raw
                        $DisplayName = $policy.BaseName

                        #Create JSON Body
                        $Content = Get-Content -LiteralPath $policy.FullName
                        $JSON_Convert = $Content | ConvertFrom-Json | Select-Object -Property * -ExcludeProperty id,createdDateTime,lastModifiedDateTime,deviceConfigurationId,macOSCustomConfigurationReferenceUrl
                        $JSON_Convert.supportsScopeTags = $false
                                                
                        if ($DisplayName -eq "macOS - C - DFE - Onboarding")
                            {
                                if (Test-Path (Join-Path $PSScriptRoot "..\..\..\customers\$($customername)\Defender_for_Endpoint\WindowsDefenderATPOnboarding.xml"))
                                {
                                    $Onboarding_XML = get-content (Join-Path $PSScriptRoot "..\..\..\customers\$($customername)\Defender_for_Endpoint\WindowsDefenderATPOnboarding.xml")
                                    $Payload = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($Onboarding_XML))
                                    $JSON_Convert.payload = $Payload
                                    $JSON_Output = $JSON_Convert | ConvertTo-Json -Depth 100
                            
                                    write-host "Create Device Configuration $($DisplayName)"
                                    $Uri = "https://graph.microsoft.com/beta/deviceManagement/deviceConfigurations"
                                    $PolicyObject = Call_RestMethod -Method Post -body $JSON_Output -Uri $uri -token $token
                                }
                                elseif (!(Test-Path (Join-Path $PSScriptRoot "..\..\..\customers\$($customername)\WindowsDefenderATPOnboarding.xml")))
                                {
                                    write-host "No WindowsDefenderATPOnboarding.xml found for $($customername) - skipping" -ForegroundColor Yellow
                                }
                            }
                        else
                            {     
                                $JSON_Output = $JSON_Convert | ConvertTo-Json -Depth 100
                                write-host "Create Device Configuration $($DisplayName)"
                                $Uri = "https://graph.microsoft.com/beta/deviceManagement/deviceConfigurations"
                                $PolicyObject = Call_RestMethod -Method Post -body $JSON_Output -Uri $uri -token $token
                            }
                        if($PolicyObject)
                            {
                            $policyid = $PolicyObject.id
                            $uri = "https://graph.microsoft.com/beta/deviceManagement/deviceConfigurations/$($policyid)/assign"
                            
                            if ($DisplayName -like "* - C - *")
                                {
                                    $JSON = "{'assignments':[{'id':'','target':{'@odata.type':'#microsoft.graph.allDevicesAssignmentTarget','deviceAndAppManagementAssignmentFilterId':null,'deviceAndAppManagementAssignmentFilterType':'none'}}]}"
                                    $PolicyObject = Call_RestMethod -Method Post -body $JSON -Uri $uri -token $token
                                }
                            elseif ($DisplayName -like "* - U - *")
                                {
                                    $JSON = "{'assignments':[{'id':'','target':{'@odata.type':'#microsoft.graph.allLicensedUsersAssignmentTarget','deviceAndAppManagementAssignmentFilterId':null,'deviceAndAppManagementAssignmentFilterType':'none'}}]}"
                                    $PolicyObject = Call_RestMethod -Method Post -body $JSON -Uri $uri -token $token
                                }   
                            else     
                                {
                                write-host Naming convention not correct - skipping assignment -ForegroundColor Yellow
                                }
                        }
                    }
                    elseif ($update -eq $true)
                    {
                        $Policyid = $Existing_Policy.value.id
                        $uri = "https://graph.microsoft.com/beta/deviceManagement/deviceConfigurations/$($Policyid)"

                        $JSON = Get-Content -Path (Join-Path $JSON_Location "$($policy.BaseName).json") -Raw
                        $DisplayName = $policy.BaseName

                        #Create JSON Body
                        $Content = Get-Content -LiteralPath $policy.FullName
                        $JSON_Convert = $Content | ConvertFrom-Json | Select-Object -Property * -ExcludeProperty id,createdDateTime,lastModifiedDateTime,deviceConfigurationId,macOSCustomConfigurationReferenceUrl,windowsHealthMonitoringConfigurationReferenceUrl,roleScopeTagIds,supportsScopeTags,qualityUpdatesPauseStartDate,featureUpdatesPauseStartDate,qualityUpdatesWillBeRolledBack,featureUpdatesWillBeRolledBack,windowsUpdateForBusinessConfigurationReferenceUrl

                        if ($DisplayName -eq "macOS - C - DFE - Onboarding")
                            {
                                if (Test-Path (Join-Path $PSScriptRoot "..\..\..\customers\$($customername)\Defender_for_Endpoint\WindowsDefenderATPOnboarding.xml"))
                                {
                                    $Onboarding_XML = get-content (Join-Path $PSScriptRoot "..\..\..\customers\$($customername)\Defender_for_Endpoint\WindowsDefenderATPOnboarding.xml")
                                    $Payload = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($Onboarding_XML))
                                    $JSON_Convert.payload = $Payload
                                    $JSON_Output = $JSON_Convert | ConvertTo-Json -Depth 100
                                    write-host "Updating Device Configuration Policy $($DisplayName)"
                                    $PolicyObject = Call_RestMethod -Method Patch -body $JSON_Output -Uri $uri -token $token
                                }
                                elseif (!(Test-Path (Join-Path $PSScriptRoot "..\..\..\customers\$($customername)\WindowsDefenderATPOnboarding.xml")))
                                {
                                    write-host "No WindowsDefenderATPOnboarding.xml found for $($customername) - skipping" -ForegroundColor Yellow
                                }
                            }
                        else
                            {     
                                $JSON_Output = $JSON_Convert | ConvertTo-Json -Depth 100
                                write-host "Updating Device Configuration Policy $($DisplayName)"
                                $PolicyObject = Call_RestMethod -Method Patch -body $JSON_Output -Uri $uri -token $token
                            }
                    }
                    else
                    {
                        write-host "$($Policy_Name) already exists, no update selected - skipping" -ForegroundColor Yellow
                    }
                }
            }
invoke-IntuneRestoreConfigurationPolicy $windows $macOS $Update $customername