param LA_Workspace string

resource diagnosticSettings 'microsoft.aadiam/diagnosticSettings@2017-04-01' = {
  name: 'Diagnostics_to_LogAnalytics'
  scope: tenant()
  properties: {
    workspaceId: LA_Workspace
    logs: [
        {
          enabled: true
          category: 'AuditLogs'
        }
        {
          enabled: true
          category: 'SignInLogs'
        }
        {
          enabled: true
          category: 'NonInteractiveUserSignInLogs'
        }
        {
          enabled: true
          category: 'ServicePrincipalSignInLogs'
        }
        {
          enabled: true
          category: 'ManagedIdentitySignInLogs'
        }
        {
          enabled: true
          category: 'ProvisioningLogs'
        }
        {
          enabled: true
          category: 'ADFSSignInLogs'
        }
        {
          enabled: true
          category: 'RiskyUsers'
        }
        {
          enabled: true
          category: 'UserRiskEvents'
        }
        {
          enabled: true
          category: 'NetworkAccessTrafficLogs'
        }
        {
          enabled: true
          category: 'RiskyServicePrincipals'
        }
        {
          enabled: true
          category: 'ServicePrincipalRiskEvents'
        }
        {
          enabled: true
          category: 'EnrichedOffice365AuditLogs'
        }
        {
          enabled: true
          category: 'MicrosoftGraphActivityLogs'
        }
        {
          enabled: true
          category: 'RemoteNetworkHealthLogs'
        }
        {
          enabled: true
          category: 'NetworkAccessAlerts'
        }
    ]
  }
}
