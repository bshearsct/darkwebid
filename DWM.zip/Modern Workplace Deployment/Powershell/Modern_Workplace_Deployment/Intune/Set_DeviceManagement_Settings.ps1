param (
    [parameter(Mandatory=$true)][string]$token
)

. (Join-Path $PSScriptRoot "..\..\Functions\Function_Invoke-RestMethod.ps1")


function Invoke-IntuneRestoreConfigurationPolicy {

        $policy_Type = "DeviceManagement_Settings"

        #get-deploymentfiles $policy_Type
        $JSON_Location = ".\Powershell\Modern_Workplace_Deployment\Intune\baselinefiles\$($policy_Type)"

        $JSON = Get-Content -Path "$($JSON_Location)\Tenant_Settings.json" -Raw

        write-host "Updating Device Management Settings"

        $uri = "https://graph.microsoft.com/beta/deviceManagement"
        Call_RestMethod -Method patch -body $JSON -Uri $uri -token $token
                
        }
invoke-IntuneRestoreConfigurationPolicy