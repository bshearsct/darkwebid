## How to create the body for a Settings Catalog JSON

1. Connect with the Graph Explorer to https://graph.microsoft.com/beta/deviceManagement/configurationPolicies{ID} and copy the body

Add the settings value after the template reference:

Original:
    "templateReference": {
        "templateId": "{ID}",
        "templateFamily": 
        "templateDisplayName": 
        "templateDisplayVersion": 
    }

Change to:
    "templateReference": {
        "templateId": "{ID}",
        "templateFamily": 
        "templateDisplayName": 
        "templateDisplayVersion": 
    },
    "settings":  []

2. Get the settings from the policy: https://graph.microsoft.com/beta/deviceManagement/configurationPolicies/{ID}/settings

Copy the body between "value" and add it in the settings part added in step 1.