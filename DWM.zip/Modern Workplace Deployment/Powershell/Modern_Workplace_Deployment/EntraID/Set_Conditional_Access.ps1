param (
    [parameter(Mandatory=$true)][string]$Token,
    [parameter(Mandatory=$true)][string]$MAM_Configure,
    [parameter(Mandatory=$false)][string]$MAM_AllUsers,
    [parameter(Mandatory=$false)][string]$MAM_GroupName,
    [parameter(Mandatory=$false)][string]$MAM_GroupDescription
)

. (Join-Path $PSScriptRoot "..\..\Functions\Function_Invoke-RestMethod.ps1")
. (Join-Path $PSScriptRoot "..\Functions\Function_Set_Authentication_Strength.ps1")
. (Join-Path $PSScriptRoot "..\Functions\Function_Set_Conditional_Access_Locations.ps1")
. (Join-Path $PSScriptRoot "..\Functions\Function_Set_BTG_Account.ps1")
. (Join-Path $PSScriptRoot "..\Functions\Function_Set_EntraID_Group.ps1")

write-host Checking Security Defaults on the tenant
$uri = "https://graph.microsoft.com/beta/policies/identitySecurityDefaultsEnforcementPolicy"
$defaults = Call_RestMethod -Method get -Uri $uri -token $Token

if ($defaults.isEnabled -eq 'True')
    {
    Write-host Security Defaults is enabled - Disabling the feature -ForegroundColor Green
    $body = (@{"isEnabled"="False"} | ConvertTo-Json)
    $uri = "https://graph.microsoft.com/beta/policies/identitySecurityDefaultsEnforcementPolicy"
    $policy = Call_RestMethod -Method patch -Uri $uri -token $Token -body $body
    start-sleep 5
    }
else 
    {
    write-host Security Defaults is not enabled on the tenant -ForegroundColor Green
    }


function Create_Conditional_Access_Policy {
    param (
    [parameter(Mandatory=$true)][string]$Body
    )
    $uri = "https://graph.microsoft.com/beta/identity/conditionalAccess/Policies"
    Call_RestMethod -Method post -Uri $uri -token $Token -body $Body
}

function Set_Conditional_Access {
    param (
    [parameter(Mandatory=$true)][string]$MAM_Configure,
    [parameter(Mandatory=$false)][string]$MAM_AllUsers,
    [parameter(Mandatory=$false)][string]$MAM_GroupName,
    [parameter(Mandatory=$false)][string]$MAM_GroupDescription
)

Set_Authentication_Strength
Set_Conditional_Access_Locations

$policy_Type = "Conditional_Access"
$JSON_Location = Join-Path $PSScriptRoot "..\Intune\baselinefiles\$($policy_Type)"
$policies = Get-ChildItem -Path $JSON_Location -File

foreach ($Policy in $policies)          
            {
                $JSON = Get-Content -Path (Join-Path $JSON_Location "$($policy.BaseName).json") -Raw
                $PolicyName = $JSON | ConvertFrom-Json | Select-Object -Property Displayname -ExpandProperty Displayname

                $uri = "https://graph.microsoft.com/beta/identity/conditionalAccess/policies?$" + "filter=(Displayname eq '" + $policyname + "')"
                $policy = Call_RestMethod -Method get -Uri $uri -token $Token
                if ($policy.value)
                {
                    write-host "Conditional Access rule $PolicyName Exists, skipping"
                }
                else
                {
                    if ($PolicyName -eq "Allow - FIDO2 Only - Break-the-Glass")
                        {
                            Set_BTG_Account                           
                            $JSON_Body = $JSON | ConvertFrom-Json
                            $JSON_Body.conditions.users.includeUsers += $script:BTG_User
                            
                            $uri = "https://graph.microsoft.com/beta/identity/conditionalAccess/authenticationStrength/policies?`$filter=(Displayname eq 'FIDO2 with TAP - One Time Use')"
                            $policy = Call_RestMethod -Method get -Uri $uri -token $Token

                            $JSON_Body.grantControls.authenticationStrength.id = $policy.value.id
                            $JSON = $JSON_Body | ConvertTo-Json -Depth 10

                            Create_Conditional_Access_Policy -Body $JSON
                        }
                    elseif ($PolicyName -eq "Block - Any Accept Allowed Locations - Global Admins")
                        {                      
                            if (!$script:BTG_User)
                            {
                                Set_BTG_Account
                            }                                                    
                            $JSON_Body = $JSON | ConvertFrom-Json
                            $JSON_Body.conditions.users.ExcludeUsers += $script:BTG_User
                            
                            $uri = "https://graph.microsoft.com/beta/identity/conditionalAccess/namedLocations?`$filter=(Displayname eq 'Score Utica')"
                            $Location = Call_RestMethod -Method get -Uri $uri -token $Token

                            $JSON_Body.conditions.locations.ExcludeLocations += $Location.value.id
                            $JSON = $JSON_Body | ConvertTo-Json -Depth 10

                            Create_Conditional_Access_Policy -Body $JSON
                        }
                    elseif ($PolicyName -eq "Allow - MAM - iOS and Android")
                        {
                            if ($MAM_Configure -eq "false")
                            {
                            write-host "MAM is not configured, skipping"
                            }
                            else
                            {
                            $JSON_Body = $JSON | ConvertFrom-Json

                            write-host "MAM is configured, setting up policy"

                            if ($MAM_AllUsers -eq "true")
                                {
                                $JSON_Body.conditions.users.includeUsers += "All"
                                }   
                            else
                                {
                                Set_EntraID_Group $MAM_GroupName $MAM_GroupDescription
                                $JSON_Body.conditions.users.includeUsers += $script:group.id
                                }
                            $JSON = $JSON_Body | ConvertTo-Json -Depth 10

                            Create_Conditional_Access_Policy -Body $JSON
                            }
                        }
                    else {
                        Create_Conditional_Access_Policy -Body $JSON
                        }
                }
            }
}
Set_Conditional_Access $MAM_Configure $MAM_AllUsers $MAM_GroupName $MAM_GroupDescription