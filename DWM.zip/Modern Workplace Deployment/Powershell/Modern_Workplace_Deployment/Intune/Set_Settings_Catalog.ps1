param (
    [parameter(Mandatory=$true)][string]$TenantID,
    [parameter(Mandatory=$true)][string]$Token,
    [Parameter(Mandatory=$false)][bool]$Windows,
    [Parameter(Mandatory=$false)][bool]$macOS,
    [Parameter(Mandatory=$false)][bool]$Update
)

. (Join-Path $PSScriptRoot "..\..\Functions\Function_Invoke-RestMethod.ps1")

function Invoke-IntuneRestoreConfigurationPolicy {

param (
    [Parameter(Mandatory=$false)][bool]$Windows,
    [Parameter(Mandatory=$false)][bool]$macOS,
    [Parameter(Mandatory=$false)][bool]$Update
    )

$policy_Type = "Settings_Catalog"
$JSON_Location = ".\Powershell\Modern_Workplace_Deployment\Intune\baselinefiles\$($policy_Type)"

if (($Windows -eq $true) -and ($macOS -eq $true))
    {$policies = Get-ChildItem -Path $JSON_Location -File}
elseif (($Windows -eq $true) -and ($macOS -eq $false))
    {$policies = Get-ChildItem -Path $JSON_Location -File | Where-Object name -Like "Windows*"}
elseif (($Windows -eq $false) -and ($macOS -eq $true))
    {$policies = Get-ChildItem -Path $JSON_Location -File | Where-Object name -Like "mac*"}
else
    {Write-Warning "No operating system selected"}

foreach ($policy in $policies) 
            {          
            $Policy_Name =  ($policy.BaseName -replace '_','/')
            $uri = "https://graph.microsoft.com/beta/deviceManagement/configurationPolicies?`$filter=(name eq '$($Policy_Name)')"
            $Existing_Policy = Call_RestMethod -Method get -Uri $uri -token $Token

                if (!$Existing_Policy.value)
                    {
                        #Create JSON Body
                        $Content = Get-Content -LiteralPath $policy.FullName
                        $JSON_Convert = $Content | ConvertFrom-Json | Select-Object -Property * -ExcludeProperty id, createdDateTime, lastModifiedDateTime, settingCount, creationSource
                        $DisplayName = $JSON_Convert.Name
                        if($DisplayName -like "*macOS*OneDrive*")
                        {
                            $JSON_Convert.settings[0].settingInstance.simpleSettingValue.value = $TenantID
                        }
                        if($DisplayName -like "*Windows*OneDrive*")
                        {
                            $json_convert.settings[1].settinginstance.choiceSettingValue.children[1].simpleSettingValue.value = $TenantID
                        }
                        $JSON_Output = $JSON_Convert | ConvertTo-Json -Depth 100
       
                        write-host "Create Settings Catalog $($DisplayName)"
                        $uri = "https://graph.microsoft.com/beta/deviceManagement/configurationPolicies"
                        $PolicyObject = Call_RestMethod -Method Post -body $JSON_Output -Uri $uri -token $Token

                        if($PolicyObject)
                            {
                            $policyid = $PolicyObject.id
                            $uri = "https://graph.microsoft.com/beta/deviceManagement/configurationPolicies/$($policyid)/assign"
                            
                            if ($DisplayName -like "* - C - *")
                                {
                                    $JSON = "{'assignments':[{'id':'','target':{'@odata.type':'#microsoft.graph.allDevicesAssignmentTarget','deviceAndAppManagementAssignmentFilterId':null,'deviceAndAppManagementAssignmentFilterType':'none'}}]}"
                                    Call_RestMethod -Method Post -body $JSON -Uri $uri -token $Token
                                }
                            elseif ($DisplayName -like "* - U - *")
                                {
                                    $JSON = "{'assignments':[{'id':'','target':{'@odata.type':'#microsoft.graph.allLicensedUsersAssignmentTarget','deviceAndAppManagementAssignmentFilterId':null,'deviceAndAppManagementAssignmentFilterType':'none'}}]}"
                                    Call_RestMethod -Method Post -body $JSON -Uri $uri -token $Token
                                }   
                            else     
                                {
                                write-host Naming convention not correct - skipping assignment -ForegroundColor Yellow
                                }
                        }
                    }
                    elseif ($update -eq $true)
                    {
                        $Policyid = $Existing_Policy.value.id
                        $uri = "https://graph.microsoft.com/beta/deviceManagement/configurationPolicies/$($Policyid)"
                        
                        $Content = Get-Content -LiteralPath $policy.FullName
                        $JSON_Convert = $Content | ConvertFrom-Json | Select-Object -Property * -ExcludeProperty id, createdDateTime, lastModifiedDateTime, settingCount, creationSource
                        $DisplayName = $JSON_Convert.Name
                        if($DisplayName -like "*macOS*OneDrive*")
                            {
                            $JSON_Convert.settings[0].settingInstance.simpleSettingValue.value = $TenantID
                            }
                        if($DisplayName -like "*Windows*OneDrive*")
                            {
                            $json_convert.settings[1].settinginstance.choiceSettingValue.children[1].simpleSettingValue.value = $TenantID
                            }
                        $JSON_Output = $JSON_Convert | ConvertTo-Json -Depth 100

                        write-host "Updating Settings Catalog $($DisplayName)"
                        $policyObject = Call_RestMethod -Method Put -body $JSON_Output -Uri $uri -token $Token
                    }
                    else
                    {
                        write-host "$($Policy_Name) already exists, no update selected - skipping" -ForegroundColor Yellow
                    }
                }
            }
            
invoke-IntuneRestoreConfigurationPolicy $windows $macOS $Update