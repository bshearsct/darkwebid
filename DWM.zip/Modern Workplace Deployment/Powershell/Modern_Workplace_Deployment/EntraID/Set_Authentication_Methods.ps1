param (
    [parameter(Mandatory=$true)][string]$Token
)

. (Join-Path $PSScriptRoot "..\..\Functions\Function_Invoke-RestMethod.ps1")

function Set-Authentication_Methods {

$policy_Type = "Authentication_Methods"
$JSON_Location = Join-Path $PSScriptRoot "..\Intune\baselinefiles\$($policy_Type)"
$Methods = Get-ChildItem -Path $JSON_Location -File

foreach ($method in $Methods)          
            {
                $JSON = Get-Content -Path (Join-Path $JSON_Location $method.Name) -Raw
                $policyid = $JSON | ConvertFrom-Json | Select-Object -Property id -ExpandProperty id

                Write-Host "Configuring $($policyid)"
                $uri = "https://graph.microsoft.com/beta/policies/authenticationMethodsPolicy/authenticationMethodConfigurations/$($policyid)"
                Call_RestMethod -Method patch -Uri $uri -token $Token -body $JSON
            }
}

Set-Authentication_Methods