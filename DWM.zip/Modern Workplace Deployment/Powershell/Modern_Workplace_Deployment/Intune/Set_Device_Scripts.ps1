param (
    [parameter(Mandatory=$true)][string]$Token,
    [Parameter(Mandatory=$false)][bool]$Update
)

. (Join-Path $PSScriptRoot "..\..\Functions\Function_Invoke-RestMethod.ps1")

function Invoke-Device_Scripts {

param (
    [Parameter(Mandatory=$false)][bool]$Update
    )

$policy_Type = "Device_Scripts"
$JSON_Location = ".\Powershell\Modern_Workplace_Deployment\Intune\baselinefiles\$($policy_Type)"

$policies = Get-ChildItem -Path $JSON_Location -File

foreach ($policy in $policies) 
            {
            $JSON = Get-Content -Path "$($JSON_Location)\$($Policy)" -Raw
            $PolicyName = $JSON | ConvertFrom-Json | Select-Object -Property Displayname -ExpandProperty Displayname

            $uri = "https://graph.microsoft.com/beta/deviceManagement/devicemanagementscripts?`$filter=(displayName eq '$($PolicyName)')"
            $Existing_Policy = Call_RestMethod -Method get -Uri $uri -token $Token

                if (!$Existing_Policy.value)
                    {
                        write-host "Create Device Script $($DisplayName)"
                        $uri = "https://graph.microsoft.com/beta/deviceManagement/devicemanagementscripts?/$($templateId)"
                        $PolicyObject = Call_RestMethod -Method Post -body $JSON -Uri $uri -token $Token

                        if($PolicyObject)
                            {
                            $policyid = $PolicyObject.id

                            $uri = "https://graph.microsoft.com/beta/deviceManagement/devicemanagementscripts/$($policyid)/assign"
                            
                            if ($PolicyName -like "* - C - *")
                                {
                                    $JSON = get-content -Path .\Powershell\Modern_Workplace_Deployment\JSON_Templates\Script_Device_Assignment.json -raw
                                    Call_RestMethod -Method Post -body $JSON -Uri $uri -token $Token
                                }
                            elseif ($PolicyName -like "* - U - *")
                                {
                                    $JSON = "{'assignments':[{'id':'','target':{'@odata.type':'#microsoft.graph.allLicensedUsersAssignmentTarget','deviceAndAppManagementAssignmentFilterId':null,'deviceAndAppManagementAssignmentFilterType':'none'}}]}"
                                    Call_RestMethod -Method Post -body $JSON -Uri $uri -token $Token
                                }   
                            else     
                                {
                                write-host Naming convention not correct - skipping assignment -ForegroundColor Yellow
                                }
                        }
                    }
                    elseif ($update -eq $true)
                    {
                        $Policyid = $Existing_Policy.value.id
                        $uri = "https://graph.microsoft.com/beta/deviceManagement/devicemanagementscripts/$($Policyid)"

                        write-host "Updating Device Script $($DisplayName)"
                        $PolicyObject = Call_RestMethod -Method Patch -body $JSON -Uri $uri -token $Token
                    }
                    else
                    {
                        write-host "$($Policy_Name) already exists, no update selected - skipping" -ForegroundColor Yellow
                    }
            }

        }
Invoke-Device_Scripts $Update