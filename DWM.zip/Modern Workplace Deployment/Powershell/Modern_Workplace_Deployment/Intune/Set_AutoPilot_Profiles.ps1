param (
    [parameter(Mandatory=$true)][string]$token,
    [parameter(Mandatory=$true)][string]$default_profile
)

. (Join-Path $PSScriptRoot "..\Functions\Function_Set_EntraID_Group.ps1")
. (Join-Path $PSScriptRoot "..\..\Functions\Function_Invoke-RestMethod.ps1")

function Set_AutoPilot_Profiles {

$policy_Type = "windowsAutopilotDeploymentProfiles"
$JSON_Location = Join-Path $PSScriptRoot "baselinefiles\$($policy_Type)"

$policies = Get-ChildItem -Path $JSON_Location -File

#Create Groups First
foreach ($policy in $policies) 
            {
            $JSON = Get-Content -Path (Join-Path $JSON_Location $Policy.Name) -Raw     
            #Get Policy Displayname
            $PolicyName = $JSON | ConvertFrom-Json | Select-Object -Property Displayname -ExpandProperty Displayname

                if ($PolicyName -eq $default_profile)
                    {
                    Set_EntraID_Group -GroupName "MEM-C-Autopilot-$($PolicyName)" -Group_Description "AutoPilot Group for $($PolicyName)" -DynamicGroupQuery '(device.devicePhysicalIDs -any (_ -contains "[ZTDId]"))'
                    }
                    else 
                    {
                    Set_EntraID_Group -GroupName "MEM-C-Autopilot-$($PolicyName)" -Group_Description "AutoPilot Group for $($PolicyName)"
                    }
            }

foreach ($policy in $policies) 
            {       
            $JSON = Get-Content -Path (Join-Path $JSON_Location $Policy.Name) -Raw
            
            #Get Policy Displayname
            $PolicyName = $JSON | ConvertFrom-Json | Select-Object -Property Displayname -ExpandProperty Displayname

            #Create JSON Body
            $JSON_Convert = $JSON | ConvertFrom-Json | Select-Object -Property * -ExcludeProperty id,createdDateTime,lastModifiedDateTime                  
            $JSON_Output = $JSON_Convert | ConvertTo-Json -Depth 10

            $uri = "https://graph.microsoft.com/beta/deviceManagement/$($policy_Type)?`$filter=(displayName eq '$($PolicyName)')"
            $Existing_Policy = Call_RestMethod -Method get -Uri $uri -token $token

                if (!$Existing_Policy.value)
                    {
                        write-host "Create $($policy_Type) $($PolicyName)"
                        $Uri = "https://graph.microsoft.com/beta/deviceManagement/$($policy_Type)"
                        $PolicyObject = Call_RestMethod -Method post -body $JSON_Output -Uri $uri -token $token

                        #Assign Group to Policy
                        if($PolicyObject)
                            {
                                if ($PolicyName -eq $default_profile)
                                    {
                                        Set_EntraID_Group -GroupName "MEM-C-Autopilot-$($PolicyName)" -Group_Description "AutoPilot Group for $($PolicyName)" -DynamicGroupQuery '(device.devicePhysicalIDs -any (_ -contains "[ZTDId]"))'
                                    }
                                else 
                                    {
                                        Set_EntraID_Group -GroupName "MEM-C-Autopilot-$($PolicyName)" -Group_Description "AutoPilot Group for $($PolicyName)"
                                    }                          
                                $policyid = $PolicyObject.id
                                $uri = "https://graph.microsoft.com/beta/deviceManagement/$($policy_Type)/$($policyid)/assignments"

                                $JSON = @{
                                        "@odata.type" = "#microsoft.graph.windowsAutopilotDeploymentProfileAssignment"
                                        target = @{
                                                    "@odata.type" = "#microsoft.graph.groupAssignmentTarget"
                                                    groupId = "$($script:group.id)"              
                                                    }
                                        source = "direct"
                                        } | ConvertTo-Json -Depth 3
                                Call_RestMethod -Method post -body $JSON -Uri $uri -token $token

                                if ($PolicyName -eq $default_profile)
                                    {
                                        #Get All AutoPilot Groups
                                        $uri = "https://graph.microsoft.com/beta/groups?`$filter=startswith(displayname,'MEM-C-AutoPilot')"
                                        $groups = Call_RestMethod -Method get -Uri $uri -token $token

                                        #create hashtable
                                        $hash = @{}
                                        $values = $Groups.value   

                                        foreach ($value in $values)
                                        {
                                            $hash.add($value.Displayname,$value.id)
                                        }

                                        #Remove the Groupname of the Assigned group from the hashtable
                                        $Value_to_Remove = "MEM-C-Autopilot-$($default_profile)"
                                        $hash.remove($Value_to_Remove)

                                        #Create string from the hashtable
                                        $Exclusions = ($hash.Keys | ForEach-Object {$hash[$_]}) 
                                        
                                        foreach ($Exclusion in $Exclusions)
                                            {
                                                $JSON = @{
                                                    "@odata.type" = "#microsoft.graph.windowsAutopilotDeploymentProfileAssignment"
                                                    target = @{
                                                                "@odata.type" = "#microsoft.graph.exclusionGroupAssignmentTarget"
                                                                groupId = "$($Exclusion)"              
                                                                }
                                                    source = "direct"
                                                    } | ConvertTo-Json -Depth 3
                                                Call_RestMethod -Method post -body $JSON -Uri $uri -token $token
                                            }
                                    }
                            }
                    }
                elseif ($update -eq $true)
                    {
                        $Policyid = $Existing_Policy.value.id
                        $uri = "https://graph.microsoft.com/beta/deviceManagement/$($policy_Type)/$($Policyid)"

                        write-host "Update $($policy_Type) $($PolicyName)"
                        $PolicyObject = Call_RestMethod -Method Patch -body $JSON -Uri $uri -token $token
                    }
                else
                    {
                        write-host "$($PolicyName) already exists, no update selected - skipping" -ForegroundColor Yellow
                    }
            }
}

Set_AutoPilot_Profiles $Update