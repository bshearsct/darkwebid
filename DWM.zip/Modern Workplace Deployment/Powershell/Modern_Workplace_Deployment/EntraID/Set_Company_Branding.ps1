param (
    [parameter(Mandatory=$true)][string]$TenantID,
    [parameter(Mandatory=$true)][string]$Token,
    [Parameter(Mandatory=$true)][string]$customername
)

. (Join-Path $PSScriptRoot "..\..\Functions\Function_Invoke-RestMethod.ps1")

function Set-Company_Branding {

param (
    [Parameter(Mandatory=$true)][string]$customername,
    [Parameter(Mandatory=$true)][string]$Token
    )

$Header = @{Authorization = "Bearer $($Token)" }

$Filepath = Join-Path $PSScriptRoot "..\..\..\customers\$($customername)\Company_Branding"
if(!(test-path $Filepath ))
        {
            write-host "No Company Branding folder exists - skipping" -ForegroundColor Yellow
        }
else {

    #Check if Customization Exists
    $uri = "https://graph.microsoft.com/beta/organization/$tenantID/branding/localizations/" 
    $Customization = Call_RestMethod -Method Get -Uri $uri -token $Token
    
    if (!$Customization.value)
        {
            $body = @{"backgroundColor" = "#FFFFFF"} | ConvertTo-Json
            $uri = "https://graph.microsoft.com/beta/organization/$tenantID/branding/localizations/" 
            Call_RestMethod -Method Post -Uri $uri -token $Token -body $body
        }

#region background
$background = Get-ChildItem $($Filepath) | Where-Object Name -Like background*
if (!($background))
    {
        write-host "No background.png or background.jpg exists - skipping" -ForegroundColor Yellow
    }
else
    {
    write-host "Configuring background" -ForegroundColor Green
    Add-Type -AssemblyName System.Drawing
    $image = [System.Drawing.Image]::FromFile($background.FullName)
    if (((get-item $background.FullName).Length/1KB) -gt '300')
        {
            write-host "File $background is >300KB - skipping" -ForegroundColor Yellow
        }
    elseif ((($background.FullName) -notlike "*.png") -and ($background.FullName) -notlike "*.jpg")
        {
            Write-Host "File extension is not compatible, only png and jpg is supported - skipping" -ForegroundColor Yellow
        }
    else
        {
        if ($image.Width -ne '1920p')
            {
            Write-Host "Background width should be 1920px, picture might be transformed" -ForegroundColor DarkYellow
            }
        if ($image.Height -ne '1080')
            {
            Write-Host "Background height should be 1080px, picture might be transformed" -ForegroundColor DarkYellow
            }
            $image.dispose()
            start-sleep 3
            $URLPhoto = "https://graph.microsoft.com/beta/organization/$tenantID/branding/localizations/0/backgroundimage" 
            Invoke-WebRequest -uri $URLPhoto -Headers $Header -Method Put -Infile $background.FullName -ContentType 'image/jpg' -UseBasicParsing | Out-Null
        }
    }
#endregion

#region Bannerlogo
$bannerlogo = Get-ChildItem $Filepath | Where-Object Name -Like Bannerlogo*
if (!($bannerlogo))
    {
        write-host "No bannerlogo.png or bannerlogo.jpg exists - skipping" -ForegroundColor Yellow
    }
else
    {
    write-host "Configuring Banner Logo" -ForegroundColor Green
    Add-Type -AssemblyName System.Drawing
    $image = [System.Drawing.Image]::FromFile($bannerlogo.FullName)
    if (((get-item $bannerlogo.FullName).Length/1KB) -gt '10')
        {
            write-host "File $bannerlogo is >10KB - skipping" -ForegroundColor Yellow
        }
    elseif ((($bannerlogo.FullName) -notlike "*.png") -and ($bannerlogo.FullName) -notlike "*.jpg")
        {
            Write-Host "File extension is not compatible, only png and jpg is supported - skipping" -ForegroundColor Yellow
        }
    else
        {
        if ($image.Width -ne '280')
            {
            Write-Host "Banner width should be 280px, picture might be transformed" -ForegroundColor DarkYellow
            }
        if ($image.Height -ne '60')
            {
            Write-Host "Banner height should be 60px, picture might be transformed" -ForegroundColor DarkYellow
            }
            $image.dispose()
            start-sleep 3
            $URLPhoto = "https://graph.microsoft.com/beta/organization/$tenantID/branding/localizations/0/Bannerlogo" 
            Invoke-WebRequest -uri $URLPhoto -Headers $Header -Method Put -Infile $bannerlogo.FullName -ContentType 'image/jpg' -UseBasicParsing | Out-Null
        }
    }
#endregion

#region squarelogo
$squarelogo = Get-ChildItem $($Filepath) | Where-Object Name -Like squarelogo.*
if (!($squarelogo))
    {
        write-host "No squarelogo.png or squarelogo.jpg exists - skipping" -ForegroundColor Yellow
    }
else
    {
    write-host "Configuring Square Logo" -ForegroundColor Green
    Add-Type -AssemblyName System.Drawing
    $image = [System.Drawing.Image]::FromFile($squarelogo.FullName)
    if (((get-item $squarelogo.FullName).Length/1KB) -gt '50')
        {
            write-host "File $squarelogo is >50KB - skipping" -ForegroundColor Yellow
        }
    elseif ((($squarelogo.FullName) -notlike "*.png") -and ($squarelogo.FullName) -notlike "*.jpg")
        {
            Write-Host "File extension is not compatible, only png and jpg is supported - skipping" -ForegroundColor Yellow
        }
    else
        {
        if ($image.Width -ne '240')
            {
            Write-Host "Square logo width should be 240px, picture might be transformed" -ForegroundColor DarkYellow
            }
        if ($image.Height -ne '240')
            {
            Write-Host "Square logo height should be 240px, picture might be transformed" -ForegroundColor DarkYellow
            }
            $image.dispose()
            start-sleep 3
            $URLPhoto = "https://graph.microsoft.com/beta/organization/$tenantID/branding/localizations/0/squarelogo" 
            Invoke-WebRequest -uri $URLPhoto -Headers $Header -Method Put -Infile $squarelogo.FullName -ContentType 'image/jpg' -UseBasicParsing | Out-Null
        }
    }
#endregion

#region squarelogo dark
$squarelogodark = Get-ChildItem $($Filepath) | Where-Object Name -Like squarelogodark*
if (!($squarelogodark))
    {
        write-host "No squarelogodark.png or squarelogodark.jpg exists - skipping" -ForegroundColor Yellow
    }
else
    {
    write-host "Configuring Square Logo Dark" -ForegroundColor Green
    Add-Type -AssemblyName System.Drawing
    $image = [System.Drawing.Image]::FromFile($squarelogodark.FullName)
    if (((get-item $squarelogodark.FullName).Length/1KB) -gt '50')
        {
            write-host "File $squarelogodark is >50KB - skipping" -ForegroundColor Yellow
        }
    elseif ((($squarelogodark.FullName) -notlike "*.png") -and ($squarelogodark.FullName) -notlike "*.jpg")
        {
            Write-Host "File extension is not compatible, only png and jpg is supported - skipping" -ForegroundColor Yellow
        }
    else
        {
        if ($image.Width -ne '240')
            {
            Write-Host "Square logo width should be 240px, picture might be transformed" -ForegroundColor DarkYellow
            }
        if ($image.Height -ne '240')
            {
            Write-Host "Square logo height should be 240px, picture might be transformed" -ForegroundColor DarkYellow
            }
            $image.dispose()
            start-sleep 5
            $URLPhoto = "https://graph.microsoft.com/beta/organization/$tenantID/branding/localizations/0/squareLogoDark" 
            Invoke-WebRequest -uri $URLPhoto -Headers $Header -Method Put -Infile $squarelogodark.FullName -ContentType 'image/jpg' -UseBasicParsing | Out-Null
        }
    }
#endregion
}
}