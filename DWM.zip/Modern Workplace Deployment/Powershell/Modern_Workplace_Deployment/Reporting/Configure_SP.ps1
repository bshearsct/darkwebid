param (
    [parameter(Mandatory=$true)][string]$TenantID,
    [parameter(Mandatory=$true)][string]$Token,
    [parameter(Mandatory=$true)][string]$mwp_report_version
)

. (Join-Path $PSScriptRoot "..\..\Functions\Function_Invoke-RestMethod.ps1")

function Get-ServicePrincipalId {
    param (
        [string]$appId
    )

    $appSpUri = "$GraphBase/servicePrincipals(appId='$TargetAppId')"
    try {
      $appSp = Call_RestMethod -Method GET -Uri $appSpUri -token $Token
    } catch {
      $appSp = $null
    }

    if (-not $appSp -or -not $appSp.id) {
      $createBody = @{ appId = $TargetAppId; servicePrincipalType = "Application";tags = @("WindowsAzureActiveDirectoryIntegratedApp") } | ConvertTo-Json
      $appSp = Call_RestMethod -Method POST -Uri "$GraphBase/servicePrincipals" -token $Token -Body $createBody
      if (-not $appSp.id) { throw "Failed to create Service Principal for $TargetAppId." }
      Write-Host "Created Service Principal: $($appSp.id)"
    } else {
      Write-Host "Service Principal exists: $($appSp.id)"
    }

    $script:appSpId = $appSp.id
}
function Configure_Permissions {
    param (
        [string]$resourceAppId,
        [string]$appSpId,
        [string[]]$desiredRoleValues
    )

# Get the API Service Principal (resource)
$resourceSpUri = "$GraphBase/servicePrincipals(appId='$resourceAppId')"
$resourceSp = Call_RestMethod -Method GET -Uri $resourceSpUri -token $Token
if (-not $resourceSp -or -not $resourceSp.id) {
  throw "API Service Principal not found in tenant."
}
$resourceSpId = $resourceSp.id

# Resolve desired app roles on the resource
$resolvedRoles = @{}
foreach ($roleValue in $desiredRoleValues) {
  $role = $resourceSp.appRoles | Where-Object { $_.isEnabled -and $_.value -eq $roleValue } | Select-Object -First 1
  if (-not $role) {
    $available = ($resourceSp.appRoles | Where-Object { $_.isEnabled } | Select-Object -ExpandProperty value) -join ", "
    throw "App role '$roleValue' not found on API Service Principal. Available enabled roles: $available"
  }
  $resolvedRoles[$roleValue] = $role
}

$existingAssignmentsUri = "$GraphBase/servicePrincipals/$appSpId/appRoleAssignments?`$filter=resourceId eq $resourceSpId"
$existingResponse = Call_RestMethod -Method GET -Uri $existingAssignmentsUri -token $Token

$existingAssignments = @()
if ($existingResponse.value)
    {$existingAssignments = $existingResponse.value}

# Assign any missing roles
foreach ($roleValue in $desiredRoleValues) {
  $role = $resolvedRoles[$roleValue]
  $alreadyAssigned = $false
  foreach ($a in $existingAssignments) {
   if ($a.appRoleId -eq $role.id -and $a.resourceId -eq $resourceSpId) {
     $alreadyAssigned = $true
     break
   }
  }

  if ($alreadyAssigned) {
    Write-Host "Role '$roleValue' is already assigned."
  } else {
    $assignBody = @{
      principalId = $appSpId
      resourceId  = $resourceSpId
      appRoleId   = $role.id
    } | ConvertTo-Json

    $assignUri = "$GraphBase/servicePrincipals/$appSpId/appRoleAssignments"
    $assignment = Call_RestMethod -Method POST -Uri $assignUri -token $Token -Body $assignBody
    Write-Host "Assigned role '$roleValue' to SP $appSpId."
  }
}
}

$GraphBase = "https://graph.microsoft.com/v1.0"
$GraphAppid = "00000003-0000-0000-c000-000000000000" # Microsoft Graph
$ATPAppid = "fc780465-2017-40d4-a0c5-307022471b92" # Microsoft Defender

if ($mwp_report_version -eq "1") {
    Write-host "Configuring Reporting Enterprise Application for MWP Bronze"
    $TargetAppId = "d1d80eca-e2a2-4ff3-8378-cce4fcd85f42"
    $DesiredRoleValues = @("Application.Read.All","AuditLog.Read.All","CrossTenantInformation.ReadBasic.All","Group.Read.All","Organization.Read.All","Policy.Read.All","RoleManagement.Read.All","SecurityEvents.Read.All","User.Read.All")
    
    Get-ServicePrincipalId -appId $TargetAppId
    configure_permissions -resourceAppId $GraphAppid -appSpId $appSpId -desiredRoleValues $DesiredRoleValues
    } else {
    Write-host "Configuring Reporting Enterprise Application for MWP Silver/Gold/AVD"
    $TargetAppId = "90de01a1-64b7-4e62-86ce-bd060274f1d6"
    $DesiredRoleValues = @("Application.Read.All","AuditLog.Read.All","CrossTenantInformation.ReadBasic.All","DeviceManagementConfiguration.Read.All","DeviceManagementManagedDevices.Read.All","Group.Read.All","Organization.Read.All","Policy.Read.All","Policy.Read.ConditionalAccess","PrivilegedAccess.Read.AzureAD","RoleEligibilitySchedule.Read.Directory","RoleManagement.Read.All","RoleManagement.Read.Directory","RoleManagementPolicy.Read.Directory","SecurityEvents.Read.All","User.Read.All","UserAuthenticationMethod.Read.All")
    $ATPDesiredRoleValues = @("Alert.Read.All","Machine.Read.All","score.Read.All","SecurityRecommendation.Read.All","Software.Read.All","User.Read.All","Vulnerability.Read.All")

    Get-ServicePrincipalId -appId $TargetAppId
    configure_permissions -resourceAppId $GraphAppid -appSpId $script:appSpId -desiredRoleValues $DesiredRoleValues
    configure_permissions -resourceAppId $ATPAppid -appSpId $appSpId -desiredRoleValues $ATPDesiredRoleValues
}