param location string
param la_name string
param alertname string = 'Admin Account Login - ${userprincipalname}'
param userprincipalname string = ''
param query string = 'SigninLogs\n| project UserPrincipalName \n| where UserPrincipalName == "${userprincipalname}"'
param actiongroupname string = 'AG_SU_Support'

resource loganalytics 'Microsoft.OperationalInsights/workspaces@2021-06-01' existing = {
  name: la_name
}

resource actiongroup 'Microsoft.Insights/actionGroups@2019-06-01' existing = {
  name: actiongroupname
}

resource alert 'microsoft.insights/scheduledqueryrules@2023-03-15-preview' = {
  name: alertname
  location: location
  properties: {
    actions: {
      actionGroups: [
        actiongroup.id
      ]
      customProperties: {}
    }
    displayName: alertname
    severity: 3
    enabled: true
    evaluationFrequency: 'PT5M'
    scopes: [
      loganalytics.id
    ]
    targetResourceTypes: [
      'microsoft.operationalinsights/workspaces'
    ]
    windowSize: 'PT5M'
    criteria: {
      allOf: [
        {
          query: query
          timeAggregation: 'Count'
          dimensions: []
          operator: 'GreaterThan'
          threshold: 0
          failingPeriods: {
            numberOfEvaluationPeriods: 1
            minFailingPeriodsToAlert: 1
          }
        }
      ]
    }
    autoMitigate: false
  }
}
