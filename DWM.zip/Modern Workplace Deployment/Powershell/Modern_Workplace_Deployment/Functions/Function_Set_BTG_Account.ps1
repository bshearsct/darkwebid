function Set_BTG_Account {

$uri = "https://graph.microsoft.com/beta/users?$" + "filter=startsWith(userPrincipalName, 'su-btg')"
$BTG_User = Call_RestMethod -Method get -Uri $uri -token $token

if (!$BTG_User.value)
    {
        write-host "Creating Break-the-Glass Account"
        $uri = "https://graph.microsoft.com/v1.0/domains"
        $Domains = Call_RestMethod -Method get -Uri $uri -token $token
        $Domain = $Domains.value.id | Where-Object {($_ -Like '*onmicrosoft*') -and ($_ -notlike '*mail*')} | Select-Object -First 1

        $BTG_UPN = 'su-btg_admin@' + $Domain
        $password = ([char[]]([char]33..[char]95) + ([char[]]([char]97..[char]126)) + 0..9 | sort {Get-Random})[0..64] -join ''

        $Create_BTG = @{
            "accountEnabled" = "true"
            "displayName" = "Break the Glass"
            "mailNickname" = "su-btg_admin"
            "passwordProfile" = @{
                "password" = "$($password)"
                "forceChangePasswordNextSignIn" = "false"
            }
            "userPrincipalName" = "$($BTG_UPN)"
        } | ConvertTo-Json

        $uri = "https://graph.microsoft.com/beta/users"
        $User = Call_RestMethod -Method post -body $Create_BTG -Uri $uri -token $token

        start-sleep -Seconds 10

        $uri = "https://graph.microsoft.com/v1.0/directoryRoles?$" + "filter=(Displayname eq 'Global Administrator')&" + '$select=id'
        $GA = Call_RestMethod -Method get -Uri $uri -token $token

        $GA_Assignment = @{"@odata.id" = "https://graph.microsoft.com/v1.0/directoryObjects/$($User.ID)"} | ConvertTo-Json

        $uri = 'https://graph.microsoft.com/v1.0/directoryRoles/' + $GA.value.id + '/members/$ref'
        Call_RestMethod -method post -body $GA_Assignment -Uri $uri -token $token

        $script:BTG_User = $User.id

        Write-Output $User


    }
else {
        $script:BTG_User = $BTG_User.value.id
    }
}