function Set_EntraID_Group {
    param (
        [parameter(Mandatory=$true)][string]$GroupName,
        [parameter(Mandatory=$false)][string]$Group_Description,
        [parameter(Mandatory=$false)][string]$DynamicGroupQuery
    )

    $uri = "https://graph.microsoft.com/beta/groups?`$filter=startswith(displayname,'$($GroupName)')"
    $group = Call_RestMethod -Method get -Uri $uri -token $token
    $script:group = $group.value

    if (!$group.value)
        {
        if(!$Group_Description)
            {$Group_Description = "null"}
        else
            {$Group_Description = $Group_Description}
            
        if(!$DynamicGroupQuery)
            {                
                $Body = @{
                        displayName = "$($GroupName)"
                        description = "$($Group_Description)"
                        mailEnabled = "false"
                        mailNickname = "notset"
                        securityEnabled = "true"
                } | Convertto-Json
            }
            else {
                $Body = @{
                    displayName = "$($GroupName)"
                    description = "$($Group_Description)"
                    mailEnabled = "false"
                    mailNickname = "notset"
                    groupTypes = @("DynamicMembership")
                    membershipRule = "$($DynamicGroupQuery)"
                    securityEnabled = "true"
                    membershipRuleProcessingState = "On"
                } | Convertto-Json
            }
            $uri = "https://graph.microsoft.com/beta/groups"
            $Group = Call_RestMethod -Method post -body $Body -Uri $uri -token $token
            $script:group = $group
        }        
}