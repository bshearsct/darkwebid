targetScope='subscription'
param location string
param rg_name string
param la_name string
param deploymentSuffix string

resource monitoringResourceGroup 'Microsoft.Resources/resourceGroups@2023-07-01' = {
  name: rg_name
  location: location
}

module actionGroup '.modules/ActionGroup.bicep' = {
  name: 'ActionGroup-${deploymentSuffix}'
  scope: monitoringResourceGroup
}

module AZ_Log_Analytics '.modules/LogAnalytics.bicep' = {
  name: 'LogAnalytics-${deploymentSuffix}'
  scope: monitoringResourceGroup
  params: {
    location: location
    logAnalyticsGeneralName: la_name
  }
}

module LogAnalytics_logs_from_EntraID '.modules/LogAnalytics_logs_from_EntraID.bicep' = {
  name: 'EntraIDLogs-${deploymentSuffix}'
  scope: monitoringResourceGroup
  params: {
    LA_Workspace: AZ_Log_Analytics.outputs.LA_Workspace
  }
}

module Alert_High_Priv_Admins '.modules/Alert_High_Priv_Admins.bicep' = {
  name: 'HighPrivAdmins-${deploymentSuffix}'
  scope: monitoringResourceGroup
  params: {
    location: location
    LA_Workspace: AZ_Log_Analytics.outputs.LA_Workspace
  }
}
