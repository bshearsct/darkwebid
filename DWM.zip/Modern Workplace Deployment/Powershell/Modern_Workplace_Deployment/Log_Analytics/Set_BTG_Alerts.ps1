param (
    [parameter(Mandatory = $true)][string]$Token,    
    [parameter(Mandatory = $true)][string]$TenantID,
    [parameter(Mandatory = $true)][string]$AppID,
    [parameter(Mandatory = $true)][string]$ClientSecret,
    [parameter(Mandatory = $true)][string]$SubscriptionID,
    [parameter(Mandatory = $true)][string]$ResourceGroupName,
    [parameter(Mandatory = $true)][string]$Location,
    [parameter(Mandatory = $true)][string]$LA_Name
)

. (Join-Path $PSScriptRoot "..\..\Functions\Function_Invoke-RestMethod.ps1")

$uri = "https://graph.microsoft.com/v1.0/users?`$filter=startswith(UserPrincipalName,'su-btg')"
$UPN = (Call_RestMethod -Method Get -Uri $uri -token $Token).value.UserPrincipalName

az login --service-principal -u $AppID -p $ClientSecret --tenant $TenantID
az account set --subscription $SubscriptionID

$TemplateFile = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../../Bicep/Modern_Workplace_Deployment/.modules/Alert_BreakGlass_Account.bicep'))
$DeploymentName = "BreakGlassAlert-$([DateTime]::UtcNow.ToString('yyyyMMdd-HHmmss-fffffff'))"

az deployment group create --name $DeploymentName --resource-group $ResourceGroupName `
                            --template-file "$TemplateFile" `
                            --parameter userprincipalname=$UPN location=$Location la_name=$LA_Name