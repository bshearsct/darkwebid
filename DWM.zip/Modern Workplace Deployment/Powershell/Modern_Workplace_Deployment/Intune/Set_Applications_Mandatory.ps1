param (
    [parameter(Mandatory=$true)][string]$token
)

. (Join-Path $PSScriptRoot "..\..\Functions\Function_Invoke-RestMethod.ps1")
. (Join-Path $PSScriptRoot "..\Functions\Function_Set_EntraID_Group.ps1")

$Applications = Get-ChildItem -Path (Join-Path $PSScriptRoot "baselinefiles\Applications")

foreach ($Application in $Applications)
        {
        $JSON = Get-Content -Path $Application.FullName -Raw
        $JSON_Convert = $JSON | ConvertFrom-Json
        $Application_Name = $JSON_Convert.displayName

        $uri = "https://graph.microsoft.com/beta/deviceAppManagement/mobileApps?`$filter=(displayName eq '$($Application_Name)')"
        $Existing_Application = Call_RestMethod -Method get -Uri $uri -token $token
        
        if (!$Existing_Application.value)
            {
                write-host "Create Application $($Application_Name)"
                $ApplicationObject = Call_RestMethod -Method post -Uri "https://graph.microsoft.com/beta/deviceAppManagement/mobileApps" -token $token -Body $JSON
            }
                if($ApplicationObject)
                    {
                    $ApplicationID = $ApplicationObject.id
                    $ApplicationURI = "https://graph.microsoft.com/beta/deviceAppManagement/mobileApps/$($ApplicationID)/assign"
                    start-sleep 5
                    
                    if ($Application_Name -eq "Microsoft 365 Apps for Enterprise")
                      {
                      write-host "Application $($Application_Name) excluded from group SUB - C - Multi-User Devices"
                      Set_EntraID_Group -GroupName "SUB - C - Multi-User Devices"
                      $JSON = '{"mobileAppAssignments":[{"@odata.type":"#microsoft.graph.mobileAppAssignment","intent":"required","target":{"@odata.type":"#microsoft.graph.allDevicesAssignmentTarget"}},{"@odata.type":"#microsoft.graph.mobileAppAssignment","intent":"required","target":{"@odata.type":"#microsoft.graph.exclusionGroupAssignmentTarget","groupId":"' + $script:group.id + '"}}]}'
                      }
                   else
                      {
                      write-host "Application $($Application_Name) assigned as required to all devices"
                      $JSON = '{"mobileAppAssignments":[{"@odata.type": "#microsoft.graph.mobileAppAssignment","intent":"required","target":{"@odata.type":"microsoft.graph.allDevicesAssignmentTarget"}}]}'
                      }

                      Call_RestMethod -Uri $ApplicationURI -Method Post -Body $JSON -token $token
                      }                                          
                    }
                  