param (
    [parameter(Mandatory=$true)][string]$token,
    [Parameter(Mandatory=$false)][bool]$Windows,
    [Parameter(Mandatory=$false)][bool]$macOS,
    [Parameter(Mandatory=$false)][bool]$Update

)

. (Join-Path $PSScriptRoot "..\..\Functions\Function_Invoke-RestMethod.ps1")

function Invoke-IntuneRestoreConfigurationPolicy {

param (
    [Parameter(Mandatory=$false)][bool]$Windows,
    [Parameter(Mandatory=$false)][bool]$macOS,
    [Parameter(Mandatory=$false)][bool]$Update
    )

$policy_Type = "Compliance_Policies"
$JSON_Location = Join-Path $PSScriptRoot "baselinefiles\$($policy_Type)"

if (($Windows -eq $true) -and ($macOS -eq $true))
    {$policies = Get-ChildItem -Path $JSON_Location -File}
elseif (($Windows -eq $true) -and ($macOS -eq $false))
    {$policies = Get-ChildItem -Path $JSON_Location -File | Where-Object name -Like "Windows*"}
elseif (($Windows -eq $false) -and ($macOS -eq $true))
    {$policies = Get-ChildItem -Path $JSON_Location -File | Where-Object name -Like "mac*"}
else
    {Write-Warning "No operating system selected"}

foreach ($policy in $policies) 
            {          
            $Policy_Name =  ($policy.BaseName -replace '_','/')
            $uri = "https://graph.microsoft.com/beta/deviceManagement/deviceCompliancePolicies?`$filter=(displayName eq '$($Policy_Name)')"
            $Existing_Policy = Call_RestMethod -Method get -Uri $uri -token $token

                if (!$Existing_Policy.value)
                    {
                        $JSON = Get-Content -Path (Join-Path $JSON_Location "$($policy.BaseName).json") -Raw
                        $DisplayName = $policy.BaseName

                        #Create JSON Body
                        $Content = Get-Content -LiteralPath $policy.FullName
                        $JSON_Convert = $Content | ConvertFrom-Json | Select-Object -Property * -ExcludeProperty id,createdDateTime,lastModifiedDateTime,deviceConfigurationId                    
                        if (-not ($JSON_Convert.scheduledActionsForRule)) {
                            if ($DisplayName -eq "Windows 10_11 - Drive Encryption")
                                    {$GracePeriod = '2'}
                            else
                                    {$GracePeriod = '0'}

                            $scheduledActionsForRule = @(
                                @{
                                    scheduledActionConfigurations = @(
                                        @{
                                            actionType = "block"
                                            gracePeriodHours = $($GracePeriod)
                                            notificationTemplateId = ""
                                        }
                                    )
                                }
                            )
                        $JSON_Convert | Add-Member -NotePropertyName scheduledActionsForRule -NotePropertyValue $scheduledActionsForRule
                        }
                        $JSON_Output = $JSON_Convert | ConvertTo-Json -Depth 100
                        write-host "Create Compliance Policy $($DisplayName)"
                        $uri = "https://graph.microsoft.com/beta/deviceManagement/deviceCompliancePolicies"
                        $PolicyObject = Call_RestMethod -Method post -body $JSON_Output -Uri $uri -token $token
                    
                    if($PolicyObject)
                        {
                        $policyid = $PolicyObject.id
                        $policyuri = "https://graph.microsoft.com/beta/deviceManagement/deviceCompliancePolicies/$($policyid)/assign"
                        $JSON = "{'assignments':[{'id':'','target':{'@odata.type':'#microsoft.graph.allLicensedUsersAssignmentTarget','deviceAndAppManagementAssignmentFilterId':null,'deviceAndAppManagementAssignmentFilterType':'none'}}]}"
                        Call_RestMethod -Method post -body $JSON -Uri $policyuri -token $token
                        }
                    elseif ($update -eq $true)
                        {
                            $Policyid = $Existing_Policy.value.id
                            $uri = "https://graph.microsoft.com/beta/deviceManagement/deviceCompliancePolicies/$($Policyid)"

                            $JSON = Get-Content -Path (Join-Path $JSON_Location "$($policy.BaseName).json") -Raw
                            $DisplayName = $policy.BaseName

                            #Create JSON Body
                            $Content = Get-Content -LiteralPath $policy.FullName
                            $JSON_Convert = $Content | ConvertFrom-Json | Select-Object -Property * -ExcludeProperty id,createdDateTime,lastModifiedDateTime,deviceConfigurationId                    
                            $JSON_Output = $JSON_Convert | ConvertTo-Json -Depth 100
                            write-host "Updating Compliance Policy $($DisplayName)"
                            $PolicyObject = Call_RestMethod -Method patch -body $JSON_Output -Uri $uri -token $token
                        }
                    else
                        {
                            write-host "$($Policy_Name) already exists, no update selected - skipping" -ForegroundColor Yellow
                        }
                }
            }
    }
invoke-IntuneRestoreConfigurationPolicy $windows $macOS $Update