param (
    [parameter(Mandatory=$true)][string]$token
)

. (Join-Path $PSScriptRoot "..\..\Functions\Function_Invoke-RestMethod.ps1")

function Set_Device_Enrollment_Configurations {

$policy_Type = "DeviceEnrollmentConfigurations"
$JSON_Location = ".\Powershell\Modern_Workplace_Deployment\Intune\baselinefiles\$($policy_Type)"

$policies = Get-ChildItem -Path $JSON_Location -File

foreach ($policy in $policies) 
            {       
                $JSON = Get-Content -Path "$($JSON_Location)\$($Policy.Name)" -Raw
                
                #Get Policy Configuration Type
                $Configuration_Type = $JSON | ConvertFrom-Json | Select-Object -Property deviceEnrollmentConfigurationType -ExpandProperty deviceEnrollmentConfigurationType

                #Create JSON Body
                $JSON_Convert = $JSON | ConvertFrom-Json | Select-Object -Property * -ExcludeProperty id,createdDateTime,lastModifiedDateTime                  
                $JSON_Output = $JSON_Convert | ConvertTo-Json -Depth 10

                #Get Policy Configurationtype ID
                $uri = "https://graph.microsoft.com/beta/deviceManagement/$($policy_Type)?`$filter=deviceEnrollmentConfigurationType eq '$($Configuration_Type)'"
                $Configuration_Type_ID = Call_RestMethod -Method get -Uri $uri -token $token

                #Update Policy
                $uri = "https://graph.microsoft.com/beta/deviceManagement/$($policy_Type)/$($Configuration_Type_ID)"
                Call_RestMethod -Method Patch -body $JSON_Output -Uri $uri -token $token
            }
        }

Set_Device_Enrollment_Configurations