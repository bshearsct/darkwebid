function Set_MAM_Enrollment {
    
    $Platforms = "iOS","Android"
    $groupID = $script:group.id
    
    foreach ($Platform in $Platforms)
        {
            $uri = "https://graph.microsoft.com/beta/deviceManagement/deviceEnrollmentConfigurations?`$filter=contains(displayname, 'MAM - $($Platform) - Block')"
            $Policy = Call_RestMethod -Method get -Uri $uri -token $token

            if(!$policy.value)
                {
                    $Body = @{
                        "@odata.type" = "#microsoft.graph.deviceEnrollmentPlatformRestrictionConfiguration"
                        displayName = "MAM - $($Platform) - Block"
                        platformType = "$($Platform)"
                        deviceEnrollmentConfigurationType = "singlePlatformRestriction"
                        platformRestriction = @{
                            platformBlocked = 'true'
                            personalDeviceEnrollmentBlocked = 'true'
                        }
                    } | ConvertTo-Json

                    $uri = "https://graph.microsoft.com/beta/deviceManagement/deviceEnrollmentConfigurations"
                    $Policy = Call_RestMethod -Method post -body $Body -Uri $uri -token $token
                    $PolicyID = $Policy.id     

                    $body =  @{
                        enrollmentConfigurationAssignments = @(
                            @{
                                target = @{
                                    "@odata.type" = "#microsoft.graph.groupAssignmentTarget"
                                    groupId = "$($groupID)"
                                }
                            }
                        )
                    } | ConvertTo-Json -Depth 3
                    
                    $uri = "https://graph.microsoft.com/beta/deviceManagement/deviceEnrollmentConfigurations/$($Policyid)/assign"
                    Call_RestMethod -Method post -body $Body -Uri $uri -token $token  
                }
        }
}